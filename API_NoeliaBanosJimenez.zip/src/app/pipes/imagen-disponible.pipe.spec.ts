import { ImagenDisponiblePipe } from './imagen-disponible.pipe';

describe('ImagenDisponiblePipe', () => {
  it('create an instance', () => {
    const pipe = new ImagenDisponiblePipe();
    expect(pipe).toBeTruthy();
  });
});
