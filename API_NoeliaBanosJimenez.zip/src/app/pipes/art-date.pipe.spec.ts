import { ArtDatePipe } from './art-date.pipe';

describe('ArtDatePipe', () => {
  it('create an instance', () => {
    const pipe = new ArtDatePipe();
    expect(pipe).toBeTruthy();
  });
});
